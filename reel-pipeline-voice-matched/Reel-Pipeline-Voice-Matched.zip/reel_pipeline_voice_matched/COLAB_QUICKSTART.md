# Android phone se Google Colab par run karne ke steps

1. Google Colab kholo, **Runtime → Change runtime type → T4 GPU** select karo.
2. ZIP ko Colab Files panel mein upload karo.
3. Ek code cell mein ye commands chalao:

```python
!apt-get update -qq && apt-get install -y -qq ffmpeg
!unzip -q reel_pipeline_voice_matched.zip
%cd reel_pipeline_voice_matched
!pip install -q -r requirements.txt
!pip install -q -r requirements-chatterbox.txt
```

4. Video generate karo:

```python
!python make_video.py scripts/aasman_neela.json -o out.mp4 --tts chatterbox --voice-reference voice/voice_reference.wav --language hi --device cuda --hq
```

5. Video phone mein save karne ke liye:

```python
from google.colab import files
files.download("out.mp4")
```

First run par model download hoga, isliye internet on rehna chahiye. GPU runtime recommended hai. Agar Colab GPU available nahi hai, `--device cpu` use kar sakte ho, lekin generation slow ho sakti hai.
