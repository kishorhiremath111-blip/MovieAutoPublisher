# Reel Pipeline — Separate Voice-Matched Copy

This is a **separate copy** of the supplied Reel Pipeline. The original uploaded ZIP is not modified. Scene rendering, character animation, props, captions, procedural SFX, music, output format, and script structure are retained.

## Voice matching

The default TTS engine is **Chatterbox Multilingual V3**. The pipeline feeds it the included `voice/voice_reference.wav`, extracted from the opening 12 seconds of the user-provided `1192812.mp4` sample. It uses Hindi (`hi`) and reuses the same speaker reference for every scene.

The reference was converted to mono 24 kHz WAV and lightly filtered/denoised from `1192812.mp4`. Music/SFX may remain because the source is a finished video. Chatterbox conditions on this exact reference for every generated scene, giving the closest available speaker-style match; generated speech is not a bit-for-bit copy and perfect identity is not guaranteed. A clean 10–20 second voice-only recording of the same speaker can improve the result. Use a voice recording only when you own it or have the speaker's permission.

Chatterbox's multilingual model documents Hindi support and reference-audio voice conditioning. The model card lists an MIT license; the upstream repository states that the project became archived research in August 2026, so it may not receive future maintenance.

## Install

Requirements: Python 3.10+ recommended, ffmpeg on PATH, and preferably a CUDA GPU (Google Colab GPU is suitable). The model weights are downloaded on the first run, so that first run needs internet access.

```bash
pip install -r requirements.txt
pip install -r requirements-chatterbox.txt
```

For a CUDA environment, install the PyTorch and torchaudio builds matching that machine before installing Chatterbox if the default pip build does not match its CUDA runtime. CPU inference is supported but can be very slow.

## Run the demo

From this folder:

```bash
python make_video.py scripts/aasman_neela.json -o out.mp4 --tts chatterbox --voice-reference voice/voice_reference.wav --language hi --device auto --hq
```

For a Colab GPU runtime, use `--device cuda`. For a CPU-only runtime, use `--device cpu`.

The pipeline intentionally **stops with an error** if Chatterbox or the reference audio is missing. It does not silently substitute Edge TTS, eSpeak, or another speaker when `--tts chatterbox` is selected.

## Use a different demo recording

```bash
python prepare_voice_reference.py /path/to/new_demo.mp4 --start 0 --duration 12 --output voice/voice_reference.wav
```

Use a clean section with one speaker, no overlapping dialogue, and as little music/effects as possible. This helper applies filtering and light denoising only; it does not separate vocals from music.

## Other voice modes

The copied pipeline keeps the original modes. For example:

```bash
python make_video.py scripts/aasman_neela.json -o edge_voice.mp4 --tts edge --voice hi-IN-MadhurNeural
python make_video.py scripts/aasman_neela.json -o silent_preview.mp4 --tts silent
```

Those modes do **not** use the demo speaker reference. Use `--tts chatterbox` for the reference-matched voice.

## Pipeline overview

1. `SCRIPT_PROMPT.md` — topic to `script.json`
2. `reelkit/tts.py` — Chatterbox reference voice / Edge / offline TTS
3. `reelkit/pipeline.py` — scenes, word timing, props, and timeline
4. `reelkit/sfx.py` — sound effects, music bed, and voice ducking
5. `reelkit/render.py`, `props.py`, `character.py` — animated vertical frames
6. `ffmpeg` — H.264/AAC final render

The source copy's original scene format and existing drawing/rendering features are retained.
