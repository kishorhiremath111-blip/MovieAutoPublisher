# Step 0 - topic se script.json banwao (kisi bhi AI chat me paste karo)

```
Tum ek viral Hinglish explainer-reel writer ho. Topic: "<TOPIC>"

Goal: aisi cheez jo sab log basic level pe jaante hain, lekin uski SAHI wajah nahi jaante.
Structure (8-10 scenes, total ~60 sec, har scene 1-2 chhote sentence):
 1. Hook: sawal + common (galat/adhoora) jawab
 2. Reality check: "ye galat hai"
 3-7. Sahi explanation, step by step, har step ka ek visual
 8. Bonus fact
 9. CTA: "ye video us dost ko bhejo jo ..."

Output sirf valid JSON, is format me (scripts/aasman_neela.json jaisa):
{ "meta": {...}, "scenes": [ {
   "say":   Roman Hinglish, important word *star* me,
   "tts_hi": wahi line Devanagari me (natural voice ke liye),
   "tts_en": wahi line phonetic Roman me (offline voice ke liye),
   "bg": dark|gold|red|blue|green,
   "chip": {"small":"...", "big":"...", "style": normal|green|red|blue|gold},
   "char": {"show":true, "pose": idle|point|wave|shrug|think|present},
   "elements": [ {"type": <prop>, "x":..., "y":..., "word": <word index jab dikhe>, "params": {...}} ]
} ] }

Available props: title, ocean_card, stamp, sun, prism, atmo, bars, card, sunset, phone_cta, badge, stat
Sirf wahi facts likho jo 100% sahi hon. Numbers verify karke likho.
```
