#!/usr/bin/env python3
"""Reel / Short explainer video generator.

  python make_video.py scripts/aasman_neela.json -o out.mp4
  python make_video.py scripts/aasman_neela.json -o out.mp4 --tts edge --hq      # natural Hindi voice + 1080p
  python make_video.py scripts/aasman_neela.json -o t.mp4 --stills 1.5,9,20      # quick PNG preview, no encoding
"""
import argparse
from reelkit.pipeline import run

ap = argparse.ArgumentParser()
ap.add_argument("script")
ap.add_argument("-o", "--output", default="out.mp4")
ap.add_argument("--tts", default="chatterbox", choices=["auto", "chatterbox", "edge", "espeak", "flite", "silent"],
                help="default: Chatterbox with the bundled demo voice reference")
ap.add_argument("--voice", default=None, help="edge: hi-IN-MadhurNeural / hi-IN-SwaraNeural / en-IN-PrabhatNeural ...")
ap.add_argument("--voice-reference", default=None, help="audio sample used to match the demo speaker")
ap.add_argument("--language", default=None, help="Chatterbox language code (default: hi)")
ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda", "mps"], help="TTS inference device")
ap.add_argument("--model-version", default=None, choices=["v2", "v3"], help="Chatterbox multilingual checkpoint")
ap.add_argument("--exaggeration", type=float, default=None, help="voice expressiveness (default from script metadata)")
ap.add_argument("--cfg-weight", type=float, default=None, help="Chatterbox guidance/pace weight")
ap.add_argument("--temperature", type=float, default=None, help="Chatterbox generation temperature")
ap.add_argument("--hq", action="store_true", help="1080x1920 instead of 720x1280")
ap.add_argument("--fps", type=int, default=30)
ap.add_argument("--music", type=float, default=0.20, help="background music level (0 = off)")
ap.add_argument("--preset", default="medium")
ap.add_argument("--crf", type=int, default=17)
ap.add_argument("--workers", type=int, default=0, help="render processes (default: all CPU cores)")
ap.add_argument("--preview", type=float, default=None, help="only render first N seconds")
ap.add_argument("--stills", default=None, help="comma list of seconds -> PNG stills only")
ap.add_argument("--keep-audio", action="store_true")
run(ap.parse_args())
