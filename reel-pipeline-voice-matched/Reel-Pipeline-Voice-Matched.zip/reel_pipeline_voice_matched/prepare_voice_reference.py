#!/usr/bin/env python3
"""Extract a mono, filtered voice-reference WAV from a demo video using ffmpeg.

Example:
  python prepare_voice_reference.py 1192819.mp4 --start 0 --duration 12 \
      --output voice/voice_reference.wav

This applies speech-band filtering and light denoising; it does not perform
source separation, so music or sound effects in the original may remain.
"""
import argparse
import shutil
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", help="input demo video file")
    parser.add_argument("--start", type=float, default=0.0, help="start offset in seconds")
    parser.add_argument("--duration", type=float, default=12.0, help="reference duration in seconds")
    parser.add_argument("--output", default="voice/voice_reference.wav")
    args = parser.parse_args()

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise SystemExit("ffmpeg was not found. Install ffmpeg and add it to PATH.")
    src = Path(args.video).expanduser().resolve()
    if not src.is_file():
        raise SystemExit(f"Input video not found: {src}")
    if args.start < 0 or args.duration < 6:
        raise SystemExit("Use --start >= 0 and --duration >= 6 seconds for a useful reference.")

    out = Path(args.output).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    audio_filter = (
        f"atrim=start={args.start}:duration={args.duration},"
        "asetpts=PTS-STARTPTS,highpass=f=100,lowpass=f=9000,"
        "afftdn=nf=-20,loudnorm=I=-20:TP=-2:LRA=11"
    )
    cmd = [
        ffmpeg, "-y", "-v", "error", "-i", str(src), "-vn", "-af", audio_filter,
        "-ac", "1", "-ar", "24000", "-c:a", "pcm_s16le", str(out),
    ]
    subprocess.run(cmd, check=True)
    print(f"[done] voice reference: {out}")
    print("[note] Filtering is not voice/music separation; a clean isolated voice sample works best.")


if __name__ == "__main__":
    main()
