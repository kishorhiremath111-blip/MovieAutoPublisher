"""Procedurally drawn cartoon presenter: bobbing, blinking, lip-sync (mouth driven by voice loudness), arm poses."""
import math
from PIL import Image, ImageDraw
from .util import lerp, clamp

CW, CH = 460, 700           # character canvas (logical)
OX, OY = 230, 680           # feet origin inside the canvas

SKIN = (240, 196, 164)
SKIN_D = (214, 164, 134)
HAIR = (44, 30, 26)
JACKET = (236, 170, 58)
JACKET_D = (196, 134, 38)
SHIRT = (22, 22, 28)
PANTS = (40, 42, 56)

# (upper-arm angle a, forearm angle b) in degrees; 0 = straight down, 90 = out horizontal, 180 = straight up
POSES = {
    "idle": dict(R=(14, 8), L=(14, 8)),
    "point": dict(R=(118, 128), L=(12, 6)),
    "wave": dict(R=(150, 165), L=(12, 6)),
    "shrug": dict(R=(58, 112), L=(58, 112)),
    "think": dict(R=(30, -150), L=(12, 6)),
    "present": dict(R=(88, 104), L=(88, 104)),
    "up": dict(R=(160, 170), L=(160, 170)),
}


def pose_angles(name, t):
    p = POSES.get(name, POSES["idle"])
    R, L = list(p["R"]), list(p["L"])
    if name == "wave":
        R[1] += 24 * math.sin(t * 9)
    if name in ("point", "present", "shrug"):
        R[0] += 3 * math.sin(t * 3)
    return dict(R=R, L=L)


class Character:
    def __init__(self, S, quality=1.5):
        self.S = S
        self.ss = S * quality

    def render(self, t, mouth, pose_a, pose_b, k, look=0.0, emph=0.0):
        ss = self.ss
        img = Image.new("RGBA", (int(CW * ss), int(CH * ss)), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)

        def P(x, y):
            return ((OX + x) * ss, (OY + y) * ss)

        def poly(pts, fill):
            d.polygon([P(*p) for p in pts], fill=fill)

        def ell(cx, cy, rx, ry, fill):
            a = P(cx - rx, cy - ry)
            b = P(cx + rx, cy + ry)
            d.ellipse((a[0], a[1], b[0], b[1]), fill=fill)

        def rr(x0, y0, x1, y1, r, fill):
            a, b = P(x0, y0), P(x1, y1)
            d.rounded_rectangle((a[0], a[1], b[0], b[1]), r * ss, fill=fill)

        def limb(p0, p1, w, col):
            d.line([P(*p0), P(*p1)], fill=col, width=int(w * ss))
            ell(p0[0], p0[1], w / 2, w / 2, col)
            ell(p1[0], p1[1], w / 2, w / 2, col)

        by = math.sin(t * 2.4) * 3 - mouth * 2.5
        sway = math.sin(t * 1.3) * 2
        A, B = pose_angles(pose_a, t), pose_angles(pose_b, t)

        # shadow
        ell(0, -6, 120, 16, (0, 0, 0, 90))
        # legs + shoes
        rr(-64, -250, -6, -34, 14, PANTS)
        rr(6, -250, 64, -34, 14, PANTS)
        ell(-40, -22, 46, 21, (238, 238, 244, 255))
        ell(40, -22, 46, 21, (238, 238, 244, 255))
        ell(-40, -14, 46, 9, (200, 200, 210, 255))
        ell(40, -14, 46, 9, (200, 200, 210, 255))
        # torso (jacket) + shirt
        rr(-102, -445 + by, 102, -212 + by, 44, JACKET_D)
        rr(-98, -448 + by, 94, -218 + by, 42, JACKET)
        poly([(-38, -436 + by), (38, -436 + by), (56, -216 + by), (-56, -216 + by)], SHIRT)
        poly([(-64, -450 + by), (-30, -450 + by), (0, -398 + by), (-52, -420 + by)], (246, 190, 82))
        poly([(64, -450 + by), (30, -450 + by), (0, -398 + by), (52, -420 + by)], (246, 190, 82))
        # neck
        rr(-26, -478 + by, 26, -430 + by, 10, SKIN_D)
        # arms
        for side, sgn in (("L", -1), ("R", 1)):
            a = lerp(A[side][0], B[side][0], k)
            b = lerp(A[side][1], B[side][1], k)
            sh = (sgn * 90, -410 + by)
            el = (sh[0] + sgn * math.sin(math.radians(a)) * 104, sh[1] + math.cos(math.radians(a)) * 104)
            wr = (el[0] + sgn * math.sin(math.radians(b)) * 98, el[1] + math.cos(math.radians(b)) * 98)
            limb(sh, el, 48, JACKET_D)
            limb(el, wr, 44, JACKET)
            ell(wr[0], wr[1], 26, 26, SKIN)
            if side == "R" and pose_b == "point" and k > .5:
                dx, dy = wr[0] - el[0], wr[1] - el[1]
                n = math.hypot(dx, dy) or 1
                limb(wr, (wr[0] + dx / n * 30, wr[1] + dy / n * 30), 15, SKIN)
        # head
        hy = -520 + by + math.sin(t * 5) * mouth * 3 + emph * -4
        ell(-84, hy + 8, 16, 20, SKIN_D)
        ell(84, hy + 8, 16, 20, SKIN_D)
        ell(0, hy - 8, 92, 94, HAIR)
        ell(0, hy + 10, 82, 84, SKIN)
        # fringe
        poly([(-84, hy - 44), (-62, hy - 80), (0, hy - 94), (62, hy - 80), (84, hy - 44), (54, hy - 38),
              (14, hy - 58), (-26, hy - 38), (-60, hy - 48)], HAIR)
        # cheeks
        ell(-52, hy + 38, 15, 9, (246, 160, 148, 255))
        ell(52, hy + 38, 15, 9, (246, 160, 148, 255))
        # eyes
        blink = 1.0 if (t % 3.4) > 0.14 else 0.1
        for sx in (-31, 31):
            ell(sx, hy + 2, 18, 21 * blink + 1, (255, 255, 255, 255))
            if blink > .5:
                ell(sx + look * 5, hy + 4, 9.5, 11, (30, 24, 28, 255))
                ell(sx + look * 5 + 3, hy, 3, 3, (255, 255, 255, 255))
            brow_lift = emph * 8
            d.line([P(sx - 17, hy - 30 - brow_lift), P(sx + 17, hy - 33 - brow_lift - (3 if sx > 0 else -3) * 0)],
                   fill=HAIR, width=int(7 * ss))
        # nose + mouth
        ell(0, hy + 24, 6, 8, SKIN_D)
        my = hy + 56
        if mouth < 0.1:
            a0, a1 = P(-22, my - 14), P(22, my + 12)
            d.arc((a0[0], a0[1], a1[0], a1[1]), 15, 165, fill=(120, 60, 60), width=int(5 * ss))
        else:
            ell(0, my, 15 + 9 * mouth, 4 + 17 * mouth, (80, 24, 34, 255))
            ell(0, my + 3 + 8 * mouth, 9 + 4 * mouth, 3 + 5 * mouth, (214, 98, 110, 255))
        out = img.resize((int(CW * self.S), int(CH * self.S)), Image.LANCZOS)
        return out
