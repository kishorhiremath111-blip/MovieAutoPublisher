"""script.json -> voice-over -> timeline -> sound mix -> frames -> mp4"""
import json, os, re, subprocess, sys, time, multiprocessing as mp
from pathlib import Path
import numpy as np
from . import tts as T
from . import sfx as X
from .props import PROPS
from .render import Renderer

_R = None


def _init(tl, S):
    global _R
    _R = Renderer(tl, S)


def _work(i):
    return _R.frame(i)


def parse_words(say):
    """'*emph* word.' -> [{'w','emph','brk'}]  (brk = chunk break after this word)"""
    out = []
    for raw in say.split():
        emph = raw.startswith("*") or raw.endswith("*")
        w = raw.replace("*", "")
        brk = bool(re.search(r"[.,;:?!\u2026\u0964]$", w))
        w = re.sub(r"[.,;:?!\"\u2026\u0964]+$", "", w).strip("\"")
        if w:
            out.append(dict(w=w, emph=emph, brk=brk))
    return out


def make_chunks(words, max_words=3, max_chars=20):
    chunks, cur = [], []
    for j, w in enumerate(words):
        if cur and (len(cur) >= max_words or sum(len(words[k]["w"]) + 1 for k in cur) + len(w["w"]) > max_chars):
            chunks.append(cur)
            cur = []
        cur.append(j)
        if w["brk"]:
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    return chunks


def build(script, args):
    meta = script.get("meta", {})
    engine = T.pick_engine(args.tts)
    print(f"[voice] engine = {engine}")
    project_root = Path(__file__).resolve().parents[1]
    reference_audio = getattr(args, "voice_reference", None) or meta.get("voice_reference")
    if reference_audio:
        reference_path = Path(os.path.expanduser(str(reference_audio)))
        if not reference_path.is_absolute():
            reference_path = project_root / reference_path
        reference_audio = str(reference_path.resolve())
    language = getattr(args, "language", None) or meta.get("tts_language", "hi")
    device = getattr(args, "device", "auto")
    model_version = getattr(args, "model_version", None) or meta.get("tts_model", "v3")
    exaggeration = getattr(args, "exaggeration", None)
    if exaggeration is None:
        exaggeration = float(meta.get("tts_exaggeration", 0.35))
    cfg_weight = getattr(args, "cfg_weight", None)
    if cfg_weight is None:
        cfg_weight = float(meta.get("tts_cfg_weight", 0.50))
    temperature = getattr(args, "temperature", None)
    if temperature is None:
        temperature = float(meta.get("tts_temperature", 0.65))
    fps = args.fps
    scenes_in = script["scenes"]
    scenes, voice_events, sfx_ev = [], [], []
    cur = 0.0
    prev_pose, prev_show, enter = "idle", False, 0.0
    for idx, s in enumerate(scenes_in):
        r = T.synth_scene(
            s, engine, voice=args.voice or meta.get("voice"), rate=meta.get("rate", "+6%"),
            tempo=meta.get("tempo", 1.0), reference_audio=reference_audio,
            language=language, device=device, model_version=model_version,
            exaggeration=exaggeration, cfg_weight=cfg_weight, temperature=temperature,
        )
        pre, post = s.get("pre", 0.18 if idx else 0.35), s.get("post", 0.30)
        start = cur
        dur = pre + r["dur"] + post
        end = start + dur
        words = parse_words(s["say"])
        for w, (a, b) in zip(words, r["words"]):
            w["s"], w["e"] = start + pre + a, start + pre + b
        for j in range(len(words) - 1):  # make words contiguous for smooth highlight
            words[j]["e"] = max(words[j]["e"], words[j + 1]["s"])
        chunks = []
        idxs = make_chunks(words)
        for n, ids in enumerate(idxs):
            cs = start if n == 0 else words[ids[0]]["s"]
            ce = end if n == len(idxs) - 1 else words[idxs[n + 1][0]]["s"]
            chunks.append(dict(s=cs, e=ce, idx=ids))
        # character state (inherits)
        ch = dict(show=True, pose=prev_pose if idx else "idle", x=190)
        if idx:
            ch["x"] = scenes[-1]["char"]["x"]
        ch.update(s.get("char", {}))
        if ch["show"] and not prev_show:
            enter = start
        ch["enter"] = enter
        prev_show = ch["show"]
        # elements
        els = []
        for e in s.get("elements", []):
            if "word" in e:
                t0 = words[min(e["word"], len(words) - 1)]["s"] - 0.05
            else:
                t0 = start + e.get("t", 0.25)
            t1 = end
            if "until_word" in e:
                t1 = words[min(e["until_word"], len(words) - 1)]["s"] - 0.05
            els.append(dict(type=e["type"], t=t0, end=t1, x=e.get("x", 360), y=e.get("y", 430),
                            params=e.get("params", {})))
            for dt, name in PROPS[e["type"]][3]:
                sfx_ev.append((t0 + dt, name, 1.0, 0.0))
        # sfx
        if idx > 0 and s.get("transition", "whoosh"):
            sfx_ev.append((start - 0.04, s.get("transition", "whoosh"), 0.8, -0.3 if idx % 2 else 0.3))
        if s.get("chip"):
            sfx_ev.append((start + 0.08, "tick", 1.3, 0.0))
        for e in s.get("sfx", []):
            t0 = words[min(e["word"], len(words) - 1)]["s"] if "word" in e else start + e.get("t", 0.2)
            sfx_ev.append((t0, e["name"], e.get("gain", 1.0), e.get("pan", 0.0)))
        scenes.append(dict(idx=idx, start=start, end=end, bg=s.get("bg", "dark"), rays=s.get("rays", False),
                           chip=s.get("chip"), char=ch, pose_prev=prev_pose, words=words, chunks=chunks,
                           elements=els))
        prev_pose = ch["pose"]
        voice_events.append((start + pre, r["wav"]))
        cur = end
        print(f"[scene {idx + 1}/{len(scenes_in)}] @{start:5.1f}s {dur:5.2f}s  {s['say'][:60]}")
    if script.get("meta", {}).get("boom", True):
        sfx_ev.append((0.05, "boom", 1.0, 0))
    total = cur + 0.6
    tl = dict(fps=fps, duration=total, scenes=scenes, watermark=meta.get("watermark"))
    return tl, voice_events, sfx_ev


def mouth_env(voice, fps, n):
    sr = X.SR
    sq = np.concatenate([[0], np.cumsum(voice.astype(np.float64) ** 2)])
    out = np.zeros(n)
    half = int(0.035 * sr)
    for i in range(n):
        c = int(i / fps * sr)
        a, b = max(0, c - half), min(len(voice), c + half)
        out[i] = np.sqrt((sq[b] - sq[a]) / max(1, b - a)) if b > a else 0
    ref = np.percentile(out[out > 0.003], 85) if (out > 0.003).any() else 1
    m = np.clip(out / ref, 0, 1) ** 0.8
    m = np.convolve(m, [0.25, 0.5, 0.25], mode="same")
    m[m < 0.12] = 0
    return m


def encode(tl, wav_path, out, S, fps, preset, crf, workers, limit=None):
    n = int(tl["duration"] * fps)
    if limit:
        n = min(n, int(limit * fps))
    w, h = int(720 * S), int(1280 * S)
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
           "-i", "-", "-i", wav_path, "-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-af", "loudnorm=I=-15:TP=-1.5:LRA=11", "-t", f"{n / fps:.3f}",
           "-movflags", "+faststart", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t0 = time.time()
    if workers > 1:
        pool = mp.Pool(workers, initializer=_init, initargs=(tl, S))
        it = pool.imap(_work, range(n), chunksize=6)
    else:
        _init(tl, S)
        it = (_work(i) for i in range(n))
    for i, fr in enumerate(it):
        p.stdin.write(fr)
        if i % 60 == 0:
            el = time.time() - t0
            print(f"[render] frame {i}/{n}  {el:5.0f}s  eta {el / max(1, i) * (n - i):4.0f}s", flush=True)
    p.stdin.close()
    p.wait()
    if workers > 1:
        pool.close()
    print(f"[done] {out}  ({time.time() - t0:.0f}s)")


def run(args):
    script = json.load(open(args.script, encoding="utf-8"))
    S = 1.5 if args.hq else 1.0
    tl, voice_events, sfx_ev = build(script, args)
    print(f"[timeline] {tl['duration']:.1f}s, {len(sfx_ev)} sound effects")
    stereo, voice = X.mix(tl["duration"], voice_events, sfx_ev, music_gain=args.music)
    tmp = os.path.splitext(args.output)[0] + "_audio.wav"
    X.write_wav(tmp, stereo)
    nf = int(tl["duration"] * args.fps) + 2
    tl["mouth"] = mouth_env(voice, args.fps, nf)
    if args.stills:
        _init(tl, S)
        base = os.path.splitext(args.output)[0]
        for ts in args.stills.split(","):
            p = f"{base}_still_{ts}.png"
            _R.still(float(ts)).save(p)
            print("[still]", p)
        return
    workers = args.workers or os.cpu_count() or 1
    encode(tl, tmp, args.output, S, args.fps, args.preset, args.crf, workers, args.preview)
    if not args.keep_audio:
        os.remove(tmp)
