"""Animated props. Each prop draws into its own RGBA layer (logical size lw x lh, origin top-left).
Signature: fn(c: Canvas, t: seconds since prop appeared, a: params dict).
PROPS[name] = (fn, (lw, lh), mode, [(dt, sfx_name), ...])  - mode = entrance animation, sfx = auto sound effects."""
import math, functools
import numpy as np
from PIL import Image
from .util import (Canvas, new_layer, vgrad, rounded_mask, grad_text_sprite, clamp, lerp, mix, ease_out_cubic,
                   ease_in_out, ease_out_back, SYM, MED, GOLD, WHITE, INK, VIOLET, BLUE, GREEN, YELLOW, RED, ORANGE,
                   glow_sprite)

SPECTRUM = [("Violet", VIOLET, 9.4), ("Blue", BLUE, 5.9), ("Green", GREEN, 3.0), ("Yellow", YELLOW, 2.1),
            ("Red", RED, 1.0)]


def _panel(c, w, h, top, bottom, r=36):
    """returns (Canvas to draw on, finish()) - gradient rounded panel clipped to rounded corners"""
    S = c.S
    pw, ph = int(w * S), int(h * S)
    img = vgrad(pw, ph, top, bottom)  # RGB so semi-transparent draws blend
    pc = Canvas(img, S)

    def finish(border=(255, 255, 255, 70), bw=3):
        m = rounded_mask(pw, ph, int(r * S))
        c.img.paste(img, (0, 0), m)
        if border:
            c.rrect(1, 1, w - 1, h - 1, r, outline=border, width=bw)
    return pc, finish


# ------------------------------------------------------------------ props
def sun(c, t, a):
    cx = cy = 180
    r = a.get("r", 70)
    c.glow(cx, cy, 178, (255, 160, 40), 0.9)
    n, rot = 14, t * 0.6
    for i in range(n):
        ang = rot + i * 2 * math.pi / n
        r0, r1, w = r + 12, r + 36 + 10 * math.sin(t * 4 + i), 0.10
        c.poly([(cx + math.cos(ang - w) * r0, cy + math.sin(ang - w) * r0),
                (cx + math.cos(ang) * r1, cy + math.sin(ang) * r1),
                (cx + math.cos(ang + w) * r0, cy + math.sin(ang + w) * r0)], fill=(255, 214, 80, 255))
    c.ell(cx, cy, r, fill=(255, 196, 48, 255))
    c.ell(cx - 12, cy - 14, r * .62, fill=(255, 226, 120, 255))
    if a.get("label"):
        c.text(cx, 345, a["label"], 26, WHITE, stroke=4)


def ocean_card(c, t, a):
    w, h = 500, 340
    pc, fin = _panel(c, w, h, (96, 196, 240), (8, 66, 150))
    for i in range(6):
        y0 = 90 + i * 40
        pts = [(x, y0 + 9 * math.sin(x / 38 + t * 2.4 + i)) for x in range(0, w + 10, 10)]
        pc.line(pts, (255, 255, 255, 120 - i * 12), 4)
    pc.glow(400, 70, 70, (255, 240, 180), .9)
    pc.ell(400, 70, 24, fill=(255, 240, 170, 255))
    pc.rect(0, h - 70, w, h, fill=(8, 12, 26, 215))
    pc.text(w / 2, h - 35, a.get("label", "SAMUNDAR"), 34, WHITE)
    fin()


def stamp(c, t, a):
    w, h = 440, 170
    col = tuple(a.get("color", RED))
    c.rrect(6, 6, w - 6, h - 6, 26, fill=(255, 255, 255, 235), outline=col, width=11)
    c.rrect(22, 22, w - 22, h - 22, 16, outline=col, width=4)
    c.text(w / 2, h / 2 + 3, a.get("text", "GALAT"), 86, col)


def prism(c, t, a):
    w, h = 680, 420
    ey = 210
    A, B, C = (340, 92), (236, 304), (444, 304)
    bp = clamp(t / 0.6)
    fan = ease_out_cubic((t - 0.6) / 0.9)
    c.glow(46, ey, 56, (255, 255, 255), .8)
    bx = lerp(50, 283, bp)
    c.line([(50, ey), (bx, ey)], (255, 255, 255, 80), 26)
    c.line([(50, ey), (bx, ey)], (255, 255, 255, 255), 11, True)
    cols = [RED, ORANGE, YELLOW, GREEN, BLUE, (90, 90, 255), VIOLET]
    for i, col in enumerate(cols):
        yend = ey + lerp(0, 24 + i * 24, fan)
        xend = lerp(397, 664, fan)
        c.line([(397, ey), (xend, yend)], col + (60,), 24)
        c.line([(397, ey), (xend, yend)], col + (255,), 9, True)
    c.poly([A, B, C], fill=(190, 225, 255, 70), outline=(255, 255, 255, 255))
    c.line([A, B, C, A], (255, 255, 255, 255), 5)
    if a.get("label_left"):
        c.text(150, 150, a["label_left"], 24, WHITE, stroke=4)
    if a.get("label_right") and fan > .8:
        c.text(540, 120, a["label_right"], 26, GOLD, stroke=4)


def atmo(c, t, a):
    w, h = 640, 480
    pc, fin = _panel(c, w, h, (14, 30, 78), (52, 100, 190))
    rng = np.random.default_rng(11)
    mols = [(float(rng.uniform(90, 600)), float(rng.uniform(150, 390))) for _ in range(26)]
    for mx, my in mols:
        pc.ell(mx, my, 8, fill=(170, 190, 230, 150))
    pc.glow(48, 48, 70, (255, 200, 80), .95)
    pc.ell(48, 48, 22, fill=(255, 226, 110, 255))
    T, travel = 3.4, 1.7
    for k in range(8):
        blue = k % 2 == 0
        col = BLUE if blue else RED
        s = ((t - k * 0.38) % T) / travel
        if t < k * 0.38 or s > 1.5:
            continue
        end = (110 + k * 66, 440)
        start = (60, 60)
        hit = 0.38 + 0.05 * (k % 3)
        if blue and s > hit:
            hx, hy = lerp(start[0], end[0], hit), lerp(start[1], end[1], hit)
            u = s - hit
            pc.ell(hx, hy, 10 + 18 * u, fill=(120, 190, 255, int(160 * clamp(1 - u * 2))))
            for j in range(5):
                ang = 0.5 + j * 1.3 + k
                dist = u * 260
                fade = clamp(1 - u / 0.9)
                px, py = hx + math.cos(ang) * dist, hy + math.sin(ang) * dist
                pc.line([(px - math.cos(ang) * 26 * fade, py - math.sin(ang) * 26 * fade), (px, py)],
                        col + (int(255 * fade),), 6, True)
        elif s <= 1.0:
            x, y = lerp(start[0], end[0], s), lerp(start[1], end[1], s)
            dx, dy = end[0] - start[0], end[1] - start[1]
            n = math.hypot(dx, dy)
            pc.line([(x - dx / n * 40, y - dy / n * 40), (x, y)], col + (140,), 9, True)
            pc.ell(x, y, 8, fill=col + (255,))
    pc.rect(0, 440, w, h, fill=(8, 12, 30, 200))
    pc.ell(34, 460, 8, fill=BLUE + (255,))
    pc.text(52, 460, "Neela: bikhar gaya", 20, WHITE, anchor="lm")
    pc.ell(360, 460, 8, fill=RED + (255,))
    pc.text(378, 460, "Laal: seedha nikla", 20, WHITE, anchor="lm")
    fin()


def bars(c, t, a):
    w, h = 620, 450
    c.rrect(0, 0, w, h, 34, fill=(18, 22, 34, 245), outline=(80, 92, 130, 255), width=3)
    c.text(w / 2, 46, a.get("title", "Kitna bikharta hai?"), 30, WHITE)
    hi = set(a.get("highlight", []))
    for i, (name, col, val) in enumerate(SPECTRUM):
        y = 108 + i * 66
        p = ease_out_cubic((t - 0.2 - 0.17 * i) / 0.6)
        c.text(36, y, name, 24, col, anchor="lm")
        bw = 330 * (val / 9.4) * p
        if name in hi:
            c.glow(170 + bw / 2, y, 150, col, 0.35 + 0.15 * math.sin(t * 6))
        c.rrect(170, y - 20, 170 + max(bw, 6), y + 20, 14, fill=col + (255,))
        if p > .9:
            c.text(170 + bw + 14, y, f"{val:g}x", 24, WHITE, anchor="lm")
    c.text(w / 2, h - 26, a.get("footer", "Red = 1x (reference)"), 19, (150, 160, 190), path=MED)


def card(c, t, a):
    lines = a.get("lines", [])
    w = 580
    h = 96 + 92 * len(lines)
    c.rrect(0, 0, w, h, 32, fill=(18, 22, 34, 245), outline=(80, 92, 130, 255), width=3)
    c.text(w / 2, 48, a.get("title", ""), 28, a.get("title_color", GOLD))
    for i, ln in enumerate(lines):
        p = ease_out_back((t - 0.35 - a.get('step', 0.55) * i) / 0.35)
        if p <= 0.01:
            continue
        y = 96 + 92 * i + 40
        ic = ln.get("icon", "check")
        col = GREEN if ic == "check" else RED if ic == "cross" else GOLD
        r = 24 * clamp(p, 0, 1.15)
        c.ell(52, y, r, fill=col + (255,))
        if p > .6:
            c.text(52, y - 1, "\u2713" if ic == "check" else "\u2717" if ic == "cross" else "\u2022", 28, INK, path=SYM)
        txt, size = ln["text"], 26
        while c.tw(txt, size) > w - 130 and size > 16:
            size -= 1
        c.text(92, y, txt, size, WHITE if p > .9 else (200, 200, 200), anchor="lm")


def sunset(c, t, a):
    w, h = 620, 440
    k = ease_in_out(t / 3.0)
    top = mix((50, 130, 255), (28, 36, 100), k)
    hor = mix((160, 215, 255), (255, 120, 40), k)
    pc, fin = _panel(c, w, h, top, hor, r=36)
    sy = lerp(150, 330, k)
    scol = mix((255, 250, 210), (255, 110, 40), k)
    pc.glow(310, sy, 120, scol, .8)
    pc.ell(310, sy, 40, fill=scol + (255,))
    pc.poly([(0, 380), (130, 350), (260, 372), (400, 345), (520, 368), (620, 352), (620, 440), (0, 440)],
            fill=(12, 14, 24, 255))
    pc.ell(310, 372, 8, fill=(255, 255, 255, 255))
    pc.line([(310, sy + 40), (310, 366)], scol + (255,), 4)
    if k > .55:
        al = int(255 * clamp((k - .55) / .3))
        pc.text(310, 70, a.get("label", "LAMBA RAASTA"), 34, (255, 255, 255, al), stroke=4)
    else:
        pc.text(310, 70, a.get("label_noon", "DOPAHAR"), 34, (255, 255, 255, 255), stroke=4)
    fin()


def phone_cta(c, t, a):
    w, h = 380, 560
    c.rrect(0, 0, w, h, 38, fill=(12, 14, 22, 255), outline=(90, 98, 130, 255), width=5)
    c.glow(60, 70, 44, ORANGE, .5)
    c.ell(60, 70, 30, fill=(255, 150, 40, 255))
    c.text(60, 70, a.get("letter", "S")[:1].upper(), 32, WHITE)
    c.text(108, 58, a.get("handle", "science.wala"), 24, WHITE, anchor="lm")
    c.text(108, 86, a.get("sub", "Roz ek sahi jawab"), 17, (150, 160, 190), anchor="lm", path=MED)
    following = t >= 1.0
    c.rrect(28, 130, 352, 182, 18, fill=(30, 36, 54, 255) if following else (40, 120, 255, 255))
    c.text(190, 156, "Following \u2713" if following else "Follow karo", 22, WHITE, path=SYM)
    c.text(28, 250, a.get("send_title", "Dost ko bhejo"), 20, (150, 160, 190), anchor="lm", path=MED)
    c.ell(58, 312, 24, fill=(70, 200, 120, 255))
    c.text(96, 312, a.get("friend", "Best friend"), 22, WHITE, anchor="lm")
    sent = t >= 2.4
    c.rrect(250, 288, 352, 336, 16, fill=(30, 36, 54, 255) if sent else (40, 120, 255, 255))
    c.text(301, 312, "Sent \u2713" if sent else "Send", 21, WHITE, path=SYM)
    c.rrect(28, 400, 352, 520, 20, fill=(22, 26, 40, 255))
    c.text(190, 438, a.get("cta1", "Aise hi sahi jawab"), 22, GOLD)
    c.text(190, 478, a.get("cta2", "roz ke liye follow karo"), 22, WHITE)


def badge(c, t, a):
    c.rrect(0, 0, 160, 70, 24, fill=GOLD + (255,))
    c.text(80, 36, a.get("text", "#1"), 36, INK)


def stat(c, t, a):
    col = tuple(a.get("color", GOLD))
    sp = grad_text_sprite(a.get("text", "6x"), 150, c.S, (255, 236, 150), col, 8)
    c.img.alpha_composite(sp, (int((520 * c.S - sp.width) / 2), 0)) if sp.width <= c.img.width else None
    c.text(260, 210, a.get("sub", ""), 30, WHITE, stroke=4)


def title(c, t, a):
    lines = a.get("lines", ["TITLE"])
    size = a.get("size", 78)
    for i, ln in enumerate(lines):
        p = ease_out_back((t - 0.14 * i) / 0.4)
        if p <= 0.01:
            continue
        top, bot = (a.get("top", (255, 238, 170)), a.get("bottom", (214, 140, 24))) if i % 2 == 0 else \
            ((255, 255, 255), (205, 205, 215))
        sp = grad_text_sprite(ln, size, c.S, tuple(top), tuple(bot), 9)
        cy = (size * 1.18) * (i + .5) * c.S
        s = clamp(p, 0, 1.2)
        sp2 = sp.resize((max(1, int(sp.width * s)), max(1, int(sp.height * s))), Image.BILINEAR)
        c.img.alpha_composite(sp2, (int((c.img.width - sp2.width) / 2), int(cy - sp2.height / 2))) \
            if sp2.width <= c.img.width else None


PROPS = {
    "sun": (sun, (360, 380), "pop", [(0.1, "sparkle")]),
    "ocean_card": (ocean_card, (500, 340), "pop", [(0.05, "pop")]),
    "stamp": (stamp, (440, 170), "stamp", [(0.22, "stamp")]),
    "prism": (prism, (680, 420), "pop", [(0.05, "pop"), (0.6, "sparkle")]),
    "atmo": (atmo, (640, 480), "pop", [(0.05, "pop")]),
    "bars": (bars, (620, 450), "rise", [(0.05, "pop"), (0.3, "tick"), (0.47, "tick"), (0.64, "tick"), (0.81, "tick"),
                                        (0.98, "tick")]),
    "card": (card, (580, 480), "pop", [(0.05, "pop")]),
    "sunset": (sunset, (620, 440), "pop", [(0.05, "whoosh"), (1.8, "sparkle")]),
    "phone_cta": (phone_cta, (380, 560), "rise", [(0.05, "whoosh"), (1.0, "pop"), (2.4, "ding")]),
    "badge": (badge, (160, 70), "pop", [(0.05, "pop")]),
    "stat": (stat, (520, 250), "pop", [(0.05, "ding")]),
    "title": (title, (720, 330), "none", [(0.0, "whoosh")]),
}


def draw_prop(canvas, name, x, y, t, params, remaining=9.0):
    fn, (lw, lh), mode, _ = PROPS[name]
    if name == "card":
        lh = 96 + 92 * len(params.get("lines", []))
    S = canvas.S
    layer = new_layer(lw, lh, S)
    fn(Canvas(layer, S), t, params)
    p = clamp(t / 0.45)
    scale, alpha, dy, rot = 1.0, 1.0, 0.0, params.get("rot", 0.0)
    if mode == "pop":
        scale = max(0.01, ease_out_back(p))
        alpha = clamp(p * 2.5)
    elif mode == "stamp":
        q = clamp(t / 0.22)
        scale = lerp(2.8, 1.0, ease_out_cubic(q))
        alpha = clamp(q * 3)
    elif mode == "rise":
        dy = (1 - ease_out_cubic(p)) * 140
        alpha = clamp(p * 2)
    if params.get('instant'):
        scale, alpha, dy = 1.0, 1.0, 0.0
    scale *= params.get('scale', 1.0)
    out = clamp(remaining / 0.18)
    alpha *= out
    if name == "title":
        if alpha > .99:
            canvas.img.paste(layer, (0, int(y * S)), layer)
        else:
            canvas.paste(layer, lw / 2, y + lh / 2, 1, 0, alpha)
        return
    canvas.paste(layer, x, y + dy, scale, rot, alpha)
