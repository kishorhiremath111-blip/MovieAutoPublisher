"""Frame renderer. Given the timeline dict (built in pipeline.py) produces RGB frames."""
import math
import numpy as np
from PIL import Image
from .util import (W, H, Canvas, new_layer, clamp, lerp, ease_out_cubic, ease_out_back, ease_in_out, MED, GOLD,
                   WHITE, INK)
from .props import draw_prop
from .character import Character

BG = {  # top, bottom, accent glow
    "dark": ((12, 13, 20), (42, 43, 54), (70, 110, 210)),
    "gold": ((30, 20, 8), (74, 50, 16), (255, 190, 60)),
    "red": ((34, 8, 12), (74, 22, 28), (255, 70, 60)),
    "blue": ((8, 18, 40), (24, 50, 98), (70, 150, 255)),
    "green": ((8, 28, 20), (20, 66, 46), (80, 225, 130)),
}
CHIP = {  # fill, border, text colour
    "normal": ((20, 22, 32), (120, 128, 150), (235, 235, 240)),
    "green": ((10, 40, 24), (80, 225, 130), (130, 255, 170)),
    "red": ((44, 10, 14), (255, 80, 70), (255, 130, 120)),
    "blue": ((10, 24, 52), (70, 150, 255), (150, 200, 255)),
    "gold": ((44, 34, 8), (255, 205, 60), (255, 224, 125)),
}
EMPH_COL = (120, 205, 255)


def make_bg(kind, S):
    w, h = int(W * S), int(H * S)
    top, bot, acc = BG.get(kind, BG["dark"])
    y = np.linspace(0, 1, h)[:, None, None] ** 1.4
    base = np.array(top, float) * (1 - y) + np.array(bot, float) * y
    base = np.repeat(base, w, axis=1)
    yy, xx = np.mgrid[0:h, 0:w]
    gx, gy = (xx / w - 0.5) / 0.5, (yy / h - 0.38) / 0.5
    r = np.hypot(gx * 1.1, gy * 0.9)
    base += (np.clip(1 - r, 0, 1) ** 2)[..., None] * np.array(acc, float) * 0.24
    vig = 1 - 0.6 * np.clip((np.hypot((xx / w - .5) * 1.2, (yy / h - .5)) - 0.38) / 0.65, 0, 1) ** 1.5
    base *= vig[..., None]
    return Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB")


class Renderer:
    def __init__(self, tl, S=1.0):
        self.tl, self.S = tl, S
        self.w, self.h = int(W * S), int(H * S)
        self.bgs = {}
        self.char = Character(S)
        self.fps = tl["fps"]
        rng = np.random.default_rng(5)
        self.dust = [(rng.uniform(0, W), rng.uniform(0, 1400), rng.uniform(14, 40), rng.uniform(1.5, 4),
                      rng.uniform(0, 6)) for _ in range(30)]

    def bg(self, kind):
        if kind not in self.bgs:
            self.bgs[kind] = make_bg(kind, self.S)
        return self.bgs[kind]

    def scene_at(self, t):
        sc = self.tl["scenes"]
        for s in sc:
            if s["start"] <= t < s["end"]:
                return s
        return sc[-1] if t >= sc[-1]["end"] else sc[0]

    # ---------------------------------------------------------------- pieces
    def rays(self, c, sc, t):
        cx, cy, R = 360, 330, 1500
        rot = t * 0.12
        n = 18
        for i in range(n):
            a0 = rot + i * 2 * math.pi / n
            a1 = a0 + math.pi / n
            c.poly([(cx, cy), (cx + R * math.cos(a0), cy + R * math.sin(a0)),
                    (cx + R * math.cos(a1), cy + R * math.sin(a1))], fill=(255, 205, 90, 30))

    def dust_layer(self, c, t, acc):
        for x, y0, sp, r, ph in self.dust:
            y = 1300 - ((y0 + t * sp) % 1400)
            xx = x + math.sin(t * .8 + ph) * 14
            c.ell(xx, y, r, fill=acc + (70,))

    def chip(self, c, sc, t):
        ch = sc.get("chip")
        if not ch:
            return
        lt = t - sc["start"] - 0.06
        if lt < 0:
            return
        fill, border, tcol = CHIP.get(ch.get("style", "normal"), CHIP["normal"])
        small, big = ch.get("small"), ch.get("big")
        ws = []
        if small:
            ws.append(c.tw(small, 22, MED))
        if big:
            ws.append(c.tw(big, 34))
        w = min(660, max(ws) + 70)
        h = (36 if small else 0) + (50 if big else 0) + 26
        S = c.S
        layer = new_layer(w + 8, h + 8, S)
        lc = Canvas(layer, S)
        lc.rrect(4, 4, w + 4, h + 4, 18, fill=fill + (240,), outline=border + (255,), width=2.5)
        y = 4 + 13
        if small:
            lc.text((w + 8) / 2, y + 18, small, 22, (190, 196, 214), path=MED)
            y += 36
        if big:
            size = 34
            while lc.tw(big, size) > w - 40 and size > 18:
                size -= 1
            lc.text((w + 8) / 2, y + 25, big, size, tcol)
        p = clamp(lt / 0.35)
        rem = clamp((sc["end"] - t) / 0.15)
        c.paste(layer, 360, 150, max(0.01, ease_out_back(p)), 0, clamp(p * 3) * rem)

    def captions(self, c, sc, t):
        chunk = None
        for ch in sc["chunks"]:
            if ch["s"] <= t < ch["e"]:
                chunk = ch
        if not chunk:
            return
        ws = [sc["words"][j] for j in chunk["idx"]]
        size = 58
        texts = [w["w"].upper() for w in ws]
        space = c.tw(" ", size) * 1.1
        total = sum(c.tw(x, size) for x in texts) + space * (len(texts) - 1)
        if total > 650:
            size *= 650 / total
            space *= 650 / total
            total = 650
        x = 360 - total / 2
        act = 0
        for j, w in enumerate(ws):
            if t >= w["s"]:
                act = j
        for j, (w, txt) in enumerate(zip(ws, texts)):
            tw_ = c.tw(txt, size)
            cx = x + tw_ / 2
            col = GOLD if j == act else EMPH_COL if w.get("emph") else WHITE
            sz = size
            if j == act:
                sz = size * (1 + 0.16 * clamp(1 - (t - w["s"]) / 0.14))
            c.text(cx, 950, txt, sz, col, stroke=7)
            x += tw_ + space

    def character(self, c, sc, t, i):
        ch = sc["char"]
        if not ch["show"]:
            return
        enter = clamp((t - ch["enter"]) / 0.5)
        offx = (1 - ease_out_cubic(enter)) * -360
        k = ease_in_out((t - sc["start"]) / 0.35)
        mouth = float(self.tl["mouth"][min(i, len(self.tl["mouth"]) - 1)])
        emph = 0.0
        for w in sc["words"]:
            if w["s"] <= t < w["e"] and w.get("emph"):
                emph = 1.0
        spr = self.char.render(t, mouth, sc["pose_prev"], sc["char"]["pose"], k, emph=emph)
        c.paste(spr, ch["x"] + offx, 1262 - 350 + 0, 1, 0, 1)

    # ---------------------------------------------------------------- frame
    def frame(self, i):
        t = i / self.fps
        sc = self.scene_at(t)
        S = self.S
        img = self.bg(sc.get("bg", "dark")).copy()
        c = Canvas(img, S)
        acc = BG.get(sc.get("bg", "dark"), BG["dark"])[2]
        if sc.get("rays") or sc.get("bg") == "gold":
            self.rays(c, sc, t)
        self.dust_layer(c, t, acc)
        self.character(c, sc, t, i)
        rem = sc["end"] - t
        for el in sc["elements"]:
            lt = t - el["t"]
            if lt >= 0 and el["end"] - t > 0:
                draw_prop(c, el["type"], el["x"], el["y"], lt, el.get("params", {}), el["end"] - t)
        self.chip(c, sc, t)
        self.captions(c, sc, t)
        wm = self.tl.get("watermark")
        if wm:
            c.text(360, 1012, wm, 22, (210, 210, 220, 150), path=MED)
        lt = t - sc["start"]
        if sc["idx"] > 0 and lt < 0.26:
            z = 1 + 0.05 * (1 - ease_out_cubic(lt / 0.26))
            bw, bh = img.width / z, img.height / z
            x0, y0 = (img.width - bw) / 2, (img.height - bh) / 2
            img = img.resize((img.width, img.height), Image.BILINEAR, box=(x0, y0, x0 + bw, y0 + bh))
        return img.tobytes()

    def still(self, t):
        return Image.frombytes("RGB", (self.w, self.h), self.frame(int(round(t * self.fps))))
