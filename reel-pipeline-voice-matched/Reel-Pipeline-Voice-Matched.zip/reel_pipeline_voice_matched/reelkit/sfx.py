"""Procedural sound effects + background music bed + mixer. No downloads, no copyright issues.
Drop your own .wav files into  sfx_custom/<name>.wav  to override any built-in effect."""
import functools, os
import numpy as np
from scipy.io import wavfile
from scipy.signal import lfilter

SR = 44100
_RNG = np.random.default_rng(1234)


def _t(d):
    return np.arange(int(d * SR)) / SR


def _env(n, a=0.005, r=None):
    e = np.ones(n)
    na = max(1, int(a * SR))
    e[:na] = np.linspace(0, 1, na)
    r = r if r is not None else n / SR
    nr = min(n, max(1, int(r * SR)))
    e[-nr:] *= np.linspace(1, 0, nr) ** 2
    return e


def _lp_sweep(x, f0, f1):
    """one-pole low-pass with sweeping cutoff (python loop, short sounds only)"""
    n = len(x)
    fc = np.linspace(f0, f1, n)
    a = 1 - np.exp(-2 * np.pi * fc / SR)
    y = np.zeros(n)
    s = 0.0
    xl, al = x.tolist(), a.tolist()
    for i in range(n):
        s += al[i] * (xl[i] - s)
        y[i] = s
    return y


def whoosh(d=0.5):
    n = int(d * SR)
    x = _RNG.standard_normal(n)
    y = _lp_sweep(x, 300, 5500)
    y = y - _lp_sweep(x, 40, 200)
    e = np.sin(np.linspace(0, np.pi, n)) ** 2
    return y * e * 2.2


def pop():
    t = _t(0.14)
    f = 700 * np.exp(-t * 18) + 180
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 28) * 0.9


def tick():
    t = _t(0.05)
    return np.sin(2 * np.pi * 2100 * t) * np.exp(-t * 90) * 0.7


def ding():
    t = _t(0.9)
    y = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t * k) for f, a, k in
            [(1318, 1, 4.5), (1976, .5, 6), (2637, .25, 9), (3951, .1, 14)])
    return y * 0.6


def boom():
    t = _t(0.9)
    f = 110 * np.exp(-t * 5) + 38
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 4.5)
    n = _RNG.standard_normal(len(t))
    y += _lp_sweep(n, 1800, 150) * np.exp(-t * 14) * 0.5
    return y * 1.0


def stamp():
    t = _t(0.5)
    f = 160 * np.exp(-t * 12) + 45
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)
    y += _RNG.standard_normal(len(t)) * np.exp(-t * 60) * 0.7
    return y * 1.1


def riser(d=1.3):
    n = int(d * SR)
    t = _t(d)
    f = 180 + 1400 * (t / d) ** 2
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.35
    y += _lp_sweep(_RNG.standard_normal(n), 400, 7000) * 0.7
    return y * np.linspace(0, 1, n) ** 2


def sparkle():
    out = np.zeros(int(0.9 * SR))
    for i, f in enumerate([1568, 2093, 2637, 3136, 3951]):
        t = _t(0.35)
        s = np.sin(2 * np.pi * f * t) * np.exp(-t * 11) * 0.35
        o = int(i * 0.07 * SR)
        out[o:o + len(s)] += s
    return out


def buzz():
    t = _t(0.3)
    y = np.sign(np.sin(2 * np.pi * 130 * t)) * 0.4 * (0.6 + 0.4 * np.sin(2 * np.pi * 28 * t))
    return y * _env(len(t), 0.005, 0.12)


def cash():
    out = np.zeros(int(0.7 * SR))
    for o, f in [(0, 2093), (0.09, 2793)]:
        t = _t(0.5)
        s = (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * 2.76 * f * t)) * np.exp(-t * 9) * 0.45
        i = int(o * SR)
        out[i:i + len(s)] += s
    return out


def success():
    out = np.zeros(int(1.0 * SR))
    for i, f in enumerate([523, 659, 784, 1047]):
        t = _t(0.5)
        s = np.sin(2 * np.pi * f * t) * np.exp(-t * 6) * 0.5
        o = int(i * 0.09 * SR)
        out[o:o + len(s)] += s
    return out


BUILTIN = dict(whoosh=whoosh, pop=pop, tick=tick, ding=ding, boom=boom, stamp=stamp, riser=riser,
               sparkle=sparkle, buzz=buzz, cash=cash, success=success)
GAIN = dict(whoosh=.45, pop=.5, tick=.22, ding=.38, boom=.7, stamp=.75, riser=.35, sparkle=.35, buzz=.3,
            cash=.4, success=.4)


@functools.lru_cache(maxsize=None)
def get_sfx(name):
    custom = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sfx_custom", name + ".wav")
    if os.path.exists(custom):
        sr, x = wavfile.read(custom)
        x = x.astype(np.float32) / (32768 if x.dtype == np.int16 else 1)
        return x.mean(axis=1) if x.ndim > 1 else x
    return BUILTIN[name]().astype(np.float32)


# ---------- music bed ----------
def music(dur, bpm=92, seed=3):
    n = int((dur + 1) * SR)
    t = np.arange(n) / SR
    beat = 60 / bpm
    chords = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]  # Am F C G
    mid = lambda m: 440 * 2 ** ((m - 69) / 12)
    pad = np.zeros(n)
    bar = beat * 4
    for i in range(int(dur / bar) + 2):
        ch = chords[i % 4]
        a, b = int(i * bar * SR), min(n, int((i + 1) * bar * SR + 0.3 * SR))
        if a >= n:
            break
        tt = t[a:b] - i * bar
        e = np.minimum(1, tt / 0.8) * np.exp(-np.maximum(0, tt - bar) * 6)
        for m in ch:
            for det in (-0.4, 0.4):
                pad[a:b] += np.sin(2 * np.pi * mid(m) * (1 + det / 100) * tt) * e * 0.08
        bass = np.sin(2 * np.pi * mid(ch[0] - 24) * tt) * e * 0.25
        pad[a:b] += bass
    drums = np.zeros(n)
    for k in range(int((dur + 1) / beat) + 1):
        o = int(k * beat * SR)
        if k % 4 in (0, 2):
            tk = np.arange(int(0.25 * SR)) / SR
            kick = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-tk * 22) + 42) / SR) * np.exp(-tk * 14) * 0.9
            drums[o:o + len(kick)] += kick[:max(0, n - o)] if o < n else 0
        h = int((k + 0.5) * beat * SR)
        if h < n:
            th = int(0.04 * SR)
            hat = np.diff(_RNG.standard_normal(th + 1)) * np.exp(-np.arange(th) / SR * 90) * 0.15
            drums[h:h + th] += hat[:max(0, n - h)]
    m = pad + drums * 0.8
    fade = np.minimum(1, t / 1.5) * np.minimum(1, np.maximum(0, (dur - t)) / 1.5 + 0.0)
    return (m * fade)[:int(dur * SR)].astype(np.float32)


# ---------- mixer ----------
def mix(duration, voice_events, sfx_events, music_gain=0.20, voice_gain=1.0):
    """voice_events: [(t, wav)], sfx_events: [(t, name, gain, pan)] -> stereo float32 [n,2]"""
    n = int(duration * SR)
    voice = np.zeros(n, np.float32)
    for t, w in voice_events:
        a = int(t * SR)
        b = min(n, a + len(w))
        if a < n:
            voice[a:b] += w[:b - a]
    pk = np.abs(voice).max()
    if pk > 0:
        voice *= 0.85 / pk * voice_gain
    L = np.zeros(n)
    R = np.zeros(n)
    for t, name, g, pan in sfx_events:
        s = get_sfx(name)
        a = int(t * SR)
        if a < 0:
            s = s[-a:]
            a = 0
        if a >= n:
            continue
        b = min(n, a + len(s))
        s = s[:b - a] * GAIN.get(name, .4) * g
        pl, pr = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
        L[a:b] += s * pl * 1.41
        R[a:b] += s * pr * 1.41
    # music with sidechain ducking from voice
    mus = music(duration)
    mus = np.pad(mus, (0, max(0, n - len(mus))))[:n]
    env = np.abs(voice).astype(np.float64)
    k = int(0.08 * SR)
    env = np.convolve(env, np.ones(k) / k, mode="same")
    duck = 1 - 0.65 * np.clip(env / 0.12, 0, 1)
    duck = lfilter([0.002], [1, -0.998], duck)  # smooth
    duck = np.clip(duck / max(duck.max(), 1e-6) * 1.0, 0.25, 1)
    mus = mus * duck * music_gain
    L += voice + mus
    R += voice + mus
    out = np.stack([L, R], axis=1)
    pk = np.abs(out).max()
    if pk > 0.95:
        out *= 0.95 / pk
    return out.astype(np.float32), voice


def write_wav(path, stereo):
    wavfile.write(path, SR, (np.clip(stereo, -1, 1) * 32767).astype(np.int16))
