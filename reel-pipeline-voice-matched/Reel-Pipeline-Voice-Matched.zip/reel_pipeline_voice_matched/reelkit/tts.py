"""Text-to-speech with word timings.

Engines (tried in this order for --tts auto):
  edge    : Microsoft Edge neural voices (pip install edge-tts, needs internet). Best quality, real word timings.
  espeak  : espeak-ng binary (offline, robotic).
  flite   : ffmpeg's libflite filter (offline, robotic, English only).
  silent  : no voice, timing estimated from word count.

Every engine returns:  dict(wav=float32 mono @SR, words=[(start, end), ...] one per caption word, dur=seconds)
"""
import asyncio, hashlib, os, re, shutil, subprocess, tempfile
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly

SR = 44100
_CHATTERBOX_MODEL = None
_CHATTERBOX_REF = None
_CHATTERBOX_DEVICE = None
_CHATTERBOX_VERSION = None
CACHE = os.path.join(tempfile.gettempdir(), "reelkit_tts_cache")
os.makedirs(CACHE, exist_ok=True)


# ---------- helpers ----------
def _read_wav(path):
    sr, x = wavfile.read(path)
    x = x.astype(np.float32)
    if x.ndim > 1:
        x = x.mean(axis=1)
    if x.dtype != np.float32 or np.abs(x).max() > 1.5:
        x = x / 32768.0
    return x


def _to_wav(src, dst, tempo=1.0):
    af = []
    if abs(tempo - 1) > 0.01:
        af = ["-af", f"atempo={tempo}"]
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, *af, "-ar", str(SR), "-ac", "1", dst], check=True)


def _trim(x, thr=0.012):
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x, 0.0
    a, b = max(0, idx[0] - int(0.02 * SR)), min(len(x), idx[-1] + int(0.04 * SR))
    return x[a:b], a / SR


def _weight(w):
    w = re.sub(r"[^\w]", "", w)
    if not w:
        return 0.5
    if re.search(r"[\u0900-\u097F]", w):
        return max(1.0, len(w) / 2.2)
    return float(max(1, len(re.findall(r"[aeiouyAEIOUY]+", w))))


def split_words(text):
    return [w for w in re.sub(r"\*", "", text).split() if w]


def distribute(words, t0, t1):
    ws = np.array([_weight(w) for w in words], float)
    edges = np.concatenate([[0], np.cumsum(ws)]) / ws.sum()
    return [(t0 + (t1 - t0) * edges[i], t0 + (t1 - t0) * edges[i + 1]) for i in range(len(words))]


def remap(src_times, n_dst):
    """Map N source word times onto n_dst caption words (handles different tokenisation)."""
    n = len(src_times)
    if n == n_dst:
        return list(src_times)
    t0, t1 = src_times[0][0], src_times[-1][1]
    edges_src = [s for s, _ in src_times] + [t1]
    out = []
    for j in range(n_dst):
        fa, fb = j / n_dst * n, (j + 1) / n_dst * n

        def at(f):
            i = min(int(f), n - 1)
            return edges_src[i] + (edges_src[i + 1] - edges_src[i]) * (f - i)
        out.append((at(fa), at(fb)))
    return out


# ---------- engines ----------
async def _edge_stream(text, voice, rate, pitch, out):
    import edge_tts
    kw = dict(rate=rate, pitch=pitch)
    try:
        com = edge_tts.Communicate(text, voice, boundary="WordBoundary", **kw)
    except TypeError:
        com = edge_tts.Communicate(text, voice, **kw)
    bounds = []
    with open(out, "wb") as f:
        async for ch in com.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                bounds.append((ch["offset"] / 1e7, (ch["offset"] + ch["duration"]) / 1e7))
    return bounds


def tts_edge(text, cap_words, voice="hi-IN-MadhurNeural", rate="+6%", pitch="+0Hz", **_):
    mp3 = os.path.join(CACHE, hashlib.md5(f"{voice}{rate}{pitch}{text}".encode()).hexdigest() + ".mp3")
    wav = mp3 + ".wav"
    bpath = mp3 + ".json"
    import json
    if not (os.path.exists(wav) and os.path.exists(bpath)):
        bounds = asyncio.run(_edge_stream(text, voice, rate, pitch, mp3))
        _to_wav(mp3, wav)
        json.dump(bounds, open(bpath, "w"))
    bounds = json.load(open(bpath))
    x = _read_wav(wav)
    xt, lead = _trim(x)
    if bounds:
        times = [(max(0, s - lead), max(0, e - lead)) for s, e in bounds]
        times = remap(times, len(cap_words))
    else:
        times = distribute(cap_words, 0, len(xt) / SR)
    return dict(wav=xt, words=times, dur=len(xt) / SR)


def _clauses(text):
    parts = re.findall(r"[^,.;:?!\u2026\u0964]+[,.;:?!\u2026\u0964]*", text)
    return [p.strip() for p in parts if re.search(r"\w", p)]


def _pause_for(clause):
    if re.search(r"[.?!\u0964\u2026]$", clause):
        return 0.30
    if re.search(r"[,;:]$", clause):
        return 0.14
    return 0.05


def _clause_engine(synth_fn):
    def run(text, cap_words, tempo=1.0, **kw):
        tw = split_words(text)
        out, times, cur = [], [], 0.0
        for cl in _clauses(text):
            cw = split_words(cl)
            raw = os.path.join(CACHE, hashlib.md5((synth_fn.__name__ + str(sorted(kw.items())) + cl).encode()).hexdigest() + ".wav")
            if not os.path.exists(raw):
                synth_fn(re.sub(r"[^\w\s\u0900-\u097F%\u20b9]", " ", cl), raw, **kw)
            x, _ = _trim(_read_wav(raw))
            if abs(tempo - 1) > 0.01:
                tmp = raw + ".t.wav"
                sf = os.path.join(CACHE, "tmp_in.wav")
                wavfile.write(sf, SR, (x * 32767).astype(np.int16))
                _to_wav(sf, tmp, tempo)
                x = _read_wav(tmp)
            d = len(x) / SR
            times += distribute(cw, cur, cur + d)
            out.append(x)
            gap = _pause_for(cl)
            out.append(np.zeros(int(gap * SR), np.float32))
            cur += d + gap
        wav = np.concatenate(out) if out else np.zeros(int(0.5 * SR), np.float32)
        return dict(wav=wav, words=remap(times, len(cap_words)), dur=len(wav) / SR)
    return run


def _flite_synth(text, out, voice="slt", **_):
    tf = os.path.join(CACHE, "flite_in.txt")
    open(tf, "w").write(text)
    raw = out + ".raw.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"flite=textfile={tf}:voice={voice}",
                    "-ar", str(SR), "-ac", "1", out], check=True)


def _espeak_synth(text, out, voice="hi", speed=150, **_):
    exe = shutil.which("espeak-ng") or shutil.which("espeak")
    subprocess.run([exe, "-v", voice, "-s", str(speed), "-w", out, text], check=True)
    tmp = out + ".r.wav"
    _to_wav(out, tmp)
    shutil.move(tmp, out)


tts_flite = _clause_engine(_flite_synth)
tts_espeak = _clause_engine(_espeak_synth)


def tts_silent(text, cap_words, **_):
    d = max(1.0, 0.38 * len(cap_words))
    return dict(wav=np.zeros(int(d * SR), np.float32), words=distribute(cap_words, 0, d), dur=d)


def _load_chatterbox(device="auto", model_version="v3"):
    """Load one reusable Chatterbox multilingual model for reference-voice TTS."""
    global _CHATTERBOX_MODEL, _CHATTERBOX_DEVICE, _CHATTERBOX_VERSION, _CHATTERBOX_REF

    try:
        import torch
        from chatterbox.mtl_tts import ChatterboxMultilingualTTS
    except Exception as exc:
        raise RuntimeError(
            "Chatterbox TTS is not installed. Run: pip install -r requirements-chatterbox.txt"
        ) from exc

    requested_device = device
    if device == "auto":
        if torch.cuda.is_available():
            device = "cuda"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            device = "mps"
        else:
            device = "cpu"

    if (
        _CHATTERBOX_MODEL is None
        or _CHATTERBOX_DEVICE != device
        or _CHATTERBOX_VERSION != model_version
    ):
        print(f"[voice] loading Chatterbox multilingual {model_version} on {device}", flush=True)
        try:
            _CHATTERBOX_MODEL = ChatterboxMultilingualTTS.from_pretrained(
                device=device, t3_model=model_version
            )
        except Exception as exc:
            _CHATTERBOX_MODEL = None
            _CHATTERBOX_REF = None
            raise RuntimeError(
                f"Could not load Chatterbox {model_version} on {device}. "
                "Check the internet connection for the first model download, available RAM/VRAM, "
                "and the chatterbox-tts installation."
            ) from exc
        _CHATTERBOX_DEVICE = device
        _CHATTERBOX_VERSION = model_version
        _CHATTERBOX_REF = None

    return _CHATTERBOX_MODEL


def tts_chatterbox(
    text,
    cap_words,
    reference_audio,
    language="hi",
    device="auto",
    model_version="v3",
    exaggeration=0.35,
    cfg_weight=0.50,
    temperature=0.65,
    **_,
):
    """Clone the permitted reference speaker and synthesize Hindi speech.

    Chatterbox does not return word boundaries, so caption timings are aligned
    proportionally to the generated speech duration, as with the offline engines.
    """
    global _CHATTERBOX_REF

    if not reference_audio:
        raise RuntimeError(
            "A voice reference is required. Set meta.voice_reference or pass --voice-reference."
        )
    reference_audio = os.path.abspath(os.path.expanduser(reference_audio))
    if not os.path.isfile(reference_audio):
        raise FileNotFoundError(f"Voice reference audio was not found: {reference_audio}")
    if not text or not text.strip():
        raise ValueError("TTS text is empty.")

    model = _load_chatterbox(device=device, model_version=model_version)
    if _CHATTERBOX_REF != reference_audio or model.conds is None:
        print(f"[voice] conditioning from reference: {os.path.basename(reference_audio)}", flush=True)
        model.prepare_conditionals(reference_audio, exaggeration=float(exaggeration))
        _CHATTERBOX_REF = reference_audio

    try:
        wav = model.generate(
            text,
            language_id=language,
            exaggeration=float(exaggeration),
            cfg_weight=float(cfg_weight),
            temperature=float(temperature),
        )
    except Exception as exc:
        raise RuntimeError(
            f"Chatterbox synthesis failed for language '{language}'. "
            "The pipeline will stop instead of silently switching to another voice."
        ) from exc

    if hasattr(wav, "detach"):
        wav = wav.detach().cpu().numpy()
    x = np.asarray(wav, dtype=np.float32).squeeze()
    if x.ndim != 1 or not len(x):
        raise RuntimeError("Chatterbox returned an empty or unsupported audio shape.")

    source_sr = int(getattr(model, "sr", 24000))
    if source_sr != SR:
        from math import gcd
        g = gcd(source_sr, SR)
        x = resample_poly(x, SR // g, source_sr // g).astype(np.float32)

    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    peak = float(np.max(np.abs(x))) if len(x) else 0.0
    if peak > 1.0:
        x = x / peak
    x, _ = _trim(x, thr=0.003)
    duration = max(len(x) / SR, 0.01)
    return dict(
        wav=x.astype(np.float32),
        words=distribute(cap_words, 0.0, duration),
        dur=duration,
        engine="chatterbox",
    )


def available(engine):
    if engine == "edge":
        try:
            import edge_tts  # noqa
            return True
        except Exception:
            return False
    if engine == "espeak":
        return bool(shutil.which("espeak-ng") or shutil.which("espeak"))
    if engine == "flite":
        try:
            r = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True)
            return "flite" in r.stdout
        except Exception:
            return False
    if engine == "chatterbox":
        try:
            import chatterbox.mtl_tts  # noqa: F401
            import torch  # noqa: F401
            return True
        except Exception:
            return False
    return engine == "silent"


def pick_engine(requested="auto"):
    if requested != "auto":
        if requested == "chatterbox" and not available("chatterbox"):
            raise RuntimeError(
                "Chatterbox TTS is not installed. Run: pip install -r requirements-chatterbox.txt"
            )
        return requested
    for e in ("edge", "espeak", "flite"):
        if available(e):
            return e
    return "silent"


def synth_scene(
    scene, engine, voice=None, rate="+6%", tempo=1.0, reference_audio=None,
    language="hi", device="auto", model_version="v3", exaggeration=0.35,
    cfg_weight=0.50, temperature=0.65,
):
    """scene: dict with say / tts_hi / tts_en. Returns dict(wav, words, dur, engine)."""
    cap_words = split_words(scene["say"])
    kw = {}
    try:
        if engine == "edge":
            text = scene.get("tts_hi") or scene["say"].replace("*", "")
            r = tts_edge(text, cap_words, voice=voice or "hi-IN-MadhurNeural", rate=rate)
        elif engine == "chatterbox":
            text = scene.get("tts_hi") or scene["say"].replace("*", "")
            r = tts_chatterbox(
                text, cap_words, reference_audio=reference_audio, language=language,
                device=device, model_version=model_version, exaggeration=exaggeration,
                cfg_weight=cfg_weight, temperature=temperature,
            )
        elif engine == "espeak":
            if scene.get("tts_hi"):
                r = tts_espeak(scene["tts_hi"], cap_words, tempo=tempo, voice="hi")
            else:
                r = tts_espeak(scene.get("tts_en") or scene["say"].replace("*", ""), cap_words, tempo=tempo, voice="en-in")
        elif engine == "flite":
            r = tts_flite(scene.get("tts_en") or scene["say"].replace("*", ""), cap_words, tempo=tempo, voice="slt" if (not voice or "Neural" in voice) else voice)
        else:
            r = tts_silent(scene["say"], cap_words)
        r["engine"] = engine
        return r
    except Exception as ex:  # legacy engines retain their existing fallback behaviour
        if engine == "chatterbox":
            raise RuntimeError(f"[tts] Chatterbox voice generation stopped: {ex}") from ex
        print(f"[tts] {engine} failed ({ex}); falling back")
        for e in ("espeak", "flite", "silent"):
            if e != engine and available(e):
                return synth_scene(scene, e, voice=None, tempo=tempo)
        return tts_silent(scene["say"], cap_words)
