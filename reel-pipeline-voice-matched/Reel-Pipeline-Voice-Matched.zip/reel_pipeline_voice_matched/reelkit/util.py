"""Drawing helpers. All coordinates are LOGICAL (720x1280); Canvas multiplies by scale S."""
import math, os, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H = 720, 1280
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _first(*paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None


BOLD = _first(os.path.join(_ROOT, "fonts", "Poppins-Bold.ttf"),
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
MED = _first(os.path.join(_ROOT, "fonts", "Poppins-Medium.ttf"), BOLD)
SYM = _first(os.path.join(_ROOT, "fonts", "DejaVuSans-Bold.ttf"), BOLD)  # has check / cross glyphs

GOLD = (255, 205, 60)
WHITE = (255, 255, 255)
INK = (14, 16, 24)
VIOLET = (160, 100, 255)
BLUE = (70, 150, 255)
GREEN = (80, 225, 130)
YELLOW = (255, 225, 70)
RED = (255, 80, 70)
ORANGE = (255, 150, 50)


def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def lerp(a, b, t):
    return a + (b - a) * t


def mix(c1, c2, t):
    t = clamp(t)
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def ease_out_cubic(p):
    p = clamp(p)
    return 1 - (1 - p) ** 3


def ease_in_out(p):
    p = clamp(p)
    return p * p * (3 - 2 * p)


def ease_out_back(p, s=1.8):
    p = clamp(p) - 1
    return 1 + (s + 1) * p ** 3 + s * p ** 2


@functools.lru_cache(maxsize=256)
def get_font(path, px):
    try:
        return ImageFont.truetype(path, px)
    except Exception:
        return ImageFont.load_default(px)


@functools.lru_cache(maxsize=64)
def glow_sprite(color, size=256):
    y, x = np.mgrid[0:size, 0:size]
    r = np.hypot(x - size / 2 + .5, y - size / 2 + .5) / (size / 2)
    a = np.clip(1 - r, 0, 1) ** 2
    arr = np.zeros((size, size, 4), np.uint8)
    arr[..., :3] = color
    arr[..., 3] = (a * 255).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


def vgrad(w, h, c0, c1):
    t = np.linspace(0, 1, h)[:, None, None]
    a = np.array(c0, float)[None, None, :] * (1 - t) + np.array(c1, float)[None, None, :] * t
    a = np.repeat(a, w, axis=1)
    return Image.fromarray(a.astype(np.uint8), "RGB")


@functools.lru_cache(maxsize=64)
def rounded_mask(w, h, r):
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), r, fill=255)
    return m


class Canvas:
    def __init__(self, img, S):
        self.img, self.S = img, S
        self.d = ImageDraw.Draw(img, "RGBA") if img.mode == "RGB" else ImageDraw.Draw(img)

    def _p(self, pts):
        S = self.S
        return [(x * S, y * S) for x, y in pts]

    def rect(self, x0, y0, x1, y1, fill=None, outline=None, width=0):
        S = self.S
        self.d.rectangle((x0 * S, y0 * S, x1 * S, y1 * S), fill=fill, outline=outline, width=int(width * S))

    def rrect(self, x0, y0, x1, y1, r, fill=None, outline=None, width=0):
        S = self.S
        self.d.rounded_rectangle((x0 * S, y0 * S, x1 * S, y1 * S), r * S, fill=fill, outline=outline,
                                 width=max(0, int(round(width * S))))

    def ell(self, cx, cy, rx, ry=None, fill=None, outline=None, width=0):
        S = self.S
        ry = rx if ry is None else ry
        self.d.ellipse(((cx - rx) * S, (cy - ry) * S, (cx + rx) * S, (cy + ry) * S), fill=fill, outline=outline,
                       width=int(width * S))

    def poly(self, pts, fill=None, outline=None):
        self.d.polygon(self._p(pts), fill=fill, outline=outline)

    def line(self, pts, fill, width=1, round_caps=False):
        S = self.S
        self.d.line(self._p(pts), fill=fill, width=max(1, int(round(width * S))), joint="curve")
        if round_caps:
            for x, y in (pts[0], pts[-1]):
                self.ell(x, y, width / 2, fill=fill)

    def arc(self, box, a0, a1, fill, width):
        S = self.S
        self.d.arc(tuple(v * S for v in box), a0, a1, fill=fill, width=max(1, int(width * S)))

    def font(self, size, path=None):
        return get_font(path or BOLD, max(1, int(round(size * self.S))))

    def tw(self, s, size, path=None):
        return self.font(size, path).getlength(s) / self.S

    def text(self, x, y, s, size, fill=WHITE, anchor="mm", stroke=0, stroke_fill=(0, 0, 0), path=None):
        S = self.S
        self.d.text((x * S, y * S), s, font=self.font(size, path), fill=fill, anchor=anchor,
                    stroke_width=int(round(stroke * S)), stroke_fill=stroke_fill)

    def glow(self, cx, cy, r, color, alpha=1.0):
        S = self.S
        d = max(2, int(2 * r * S))
        sp = glow_sprite(tuple(color)).resize((d, d), Image.BILINEAR)
        if alpha < 1:
            sp.putalpha(sp.getchannel("A").point(lambda v: int(v * alpha)))
        pos = (int(cx * S - d / 2), int(cy * S - d / 2))
        if self.img.mode == "RGB":
            self.img.paste(sp, pos, sp)
        else:  # layer: composite without clobbering existing pixels
            tmp = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
            tmp.paste(sp, pos)
            self.img.alpha_composite(tmp)

    def paste(self, layer, cx, cy, scale=1.0, rot=0.0, alpha=1.0):
        """Paste RGBA `layer` (already at scale S) centred on logical (cx, cy)."""
        if alpha <= 0.01 or scale <= 0.01:
            return
        S = self.S
        sp = layer
        if abs(scale - 1) > 1e-3:
            sp = sp.resize((max(1, int(sp.width * scale)), max(1, int(sp.height * scale))), Image.BILINEAR)
        if abs(rot) > 1e-3:
            sp = sp.rotate(rot, resample=Image.BICUBIC, expand=True)
        if alpha < 0.99:
            sp = sp.copy()
            sp.putalpha(sp.getchannel("A").point(lambda v: int(v * alpha)))
        self.img.paste(sp, (int(cx * S - sp.width / 2), int(cy * S - sp.height / 2)), sp)


def new_layer(w, h, S):
    return Image.new("RGBA", (int(w * S), int(h * S)), (0, 0, 0, 0))


@functools.lru_cache(maxsize=128)
def grad_text_sprite(s, size, S, top, bottom, stroke, path=None):
    f = get_font(path or BOLD, int(size * S))
    pad = int((stroke + 10) * S)
    tw = int(f.getlength(s)) + 2 * pad
    th = int(size * S * 1.5) + 2 * pad
    mask = Image.new("L", (tw, th), 0)
    ImageDraw.Draw(mask).text((tw / 2, th / 2), s, font=f, fill=255, anchor="mm")
    sh = Image.new("L", (tw, th), 0)
    ImageDraw.Draw(sh).text((tw / 2, th / 2 + 5 * S), s, font=f, fill=255, anchor="mm",
                            stroke_width=int(stroke * S))
    out = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    out.paste(Image.new("RGBA", (tw, th), (0, 0, 0, 255)), (0, 0), sh)
    g = vgrad(tw, th, top, bottom).convert("RGBA")
    out.paste(g, (0, 0), mask)
    return out
